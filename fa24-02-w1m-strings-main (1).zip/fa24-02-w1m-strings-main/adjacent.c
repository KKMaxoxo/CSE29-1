#include <stdio.h>

int main() {
    char hi[] = "Hi all!";
    char helloeveryone[] = { 'H', 'e', 'l', 'l', 'o', ',', ' ',
                             'e', 'v', 'e', 'r', 'y', 'o', 'n', 'e', '!' };
    puts(hi);
    puts(helloeveryone);
}
